#!/system/bin/sh
MODDIR=${0%/*}
until [ "$(getprop sys.boot_completed)" -eq 1 ]; do
    sleep 5
done

sh "$MODDIR/common/functions.sh"

export PATH="/system/bin:/system/xbin:/vendor/bin:$(magisk --path)/.magisk/busybox:$PATH"
export MODDIR="/data/adb/modules/xiaoman"  # 显式定义


touch "${MODDIR}/common/functions.sh"

# 创建 Cron 配置
CRON_DIR="${MODDIR}/cron"
mkdir -p "$CRON_DIR"
crond -c "$CRON_DIR"

chmod 0755 "$CRON_DIR/root"
chmod 0755 "$MODDIR/common/functions.sh"

crond -c "$CRON_DIR"