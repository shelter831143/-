#!/system/bin/sh

MODDIR=${0%/*}
#touchHidlTest -c wo 0 182 240

#默认240 需要360采样请将240修改为360
touchHidlTest -c wo 0 182 360